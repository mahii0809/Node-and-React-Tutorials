var add=require('./add');
console.log(add.addition(5,6));
var sub=require('./subract');
console.log(sub.subtract(15,6));
var mul=require('./mul');
console.log(mul.multiply(15,6));
var div=require('./divide');
console.log(div.divide(15,6));
function mul(x,y)
{
    return x*y;
}
//export the function
module.exports.multiply=mul;
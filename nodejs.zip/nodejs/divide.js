function divide(x,y)
{
    return x/y;
}
//export the function
module.exports.divide=divide;
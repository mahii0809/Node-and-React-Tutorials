function subtract(x,y)
{
    return x-y;
}
//export the function
module.exports.subtract=subtract;
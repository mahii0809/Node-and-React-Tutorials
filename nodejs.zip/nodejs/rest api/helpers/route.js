module.exports.ROUTE_CONST={
    DEFAULT:"/",
    GET_LOGINDET:"/loginpage",
    POST_LOGIN:"/loginpage"
}

module.exports.ROUTE_CONSTANTS={
    DEFAULT:"/",
    GET_PRODUCTS:"/products",
    GET_LOGIN:"/login",
    GET_REGISTER:"/register",
    GET_FILE:"/file",
    POST_REGISTER:"/register"
}